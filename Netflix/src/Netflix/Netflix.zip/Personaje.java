package Netflix;

public class Personaje {
		private String nombre;

		@Override
		public String toString() {
			return "Personaje [nombre=" + nombre + "]\n";
		}

}
