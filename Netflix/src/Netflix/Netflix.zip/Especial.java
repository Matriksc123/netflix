package Netflix;

public class Especial extends Capitulo{

	public Especial(int num, Temporada temporada) {
		super(num, temporada);
	}
}
